-- main.lua
-- SpaceGalaxy - Command Center (Android-ready)
-- تحسينات: تحديد هوية نظام الملفات للحفظ على أندرويد، حفظ آمن مع flush محمي، حفظ عند فقدان التركيز، تقليل I/O
-- ملف الحفظ: spacegalaxy_save.lua

local SAVE_FILENAME = "spacegalaxy_save.lua"
local SAVE_IDENTITY = "SpaceGalaxy_Save"

-- -------------------------
-- Serialization (simple, safe)
-- -------------------------
local function serializeValue(v, indent)
    indent = indent or ""
    local t = type(v)
    if t == "number" or t == "boolean" then
        return tostring(v)
    elseif t == "string" then
        return string.format("%q", v)
    elseif t == "table" then
        local parts = {"{\n"}
        local nextIndent = indent .. "  "
        local numericKeys = {}
        local otherKeys = {}
        for k, _ in pairs(v) do
            if type(k) == "number" then
                table.insert(numericKeys, k)
            else
                table.insert(otherKeys, k)
            end
        end
        table.sort(numericKeys)
        table.sort(otherKeys, function(a,b) return tostring(a) < tostring(b) end)
        for _, k in ipairs(numericKeys) do
            local val = v[k]
            local key = "[" .. tostring(k) .. "] = "
            table.insert(parts, nextIndent .. key .. serializeValue(val, nextIndent) .. ",\n")
        end
        for _, k in ipairs(otherKeys) do
            local val = v[k]
            local key
            if type(k) == "string" and k:match("^%a[%w_]*$") then
                key = k .. " = "
            else
                key = "[" .. tostring(k) .. "] = "
            end
            table.insert(parts, nextIndent .. key .. serializeValue(val, nextIndent) .. ",\n")
        end
        table.insert(parts, indent .. "}")
        return table.concat(parts)
    else
        return "nil"
    end
end

-- -------------------------
-- Save / Load (persistent)
-- -------------------------
local saveTimer = 0
local saveInterval = 10 -- حفظ دوري كل 10 ثواني عند وجود تغييرات طفيفة
local saveDirty = false

local function saveGame()
    local save = {
        coinsSaved = coinsSaved or 0,
        shipOwned = shipOwned or {},
        equippedShip = equippedShip or 1,
        shotPurchases = shotPurchases or 0,
        hpPurchases = hpPurchases or 0
    }
    local chunk = "return " .. serializeValue(save)
    local ok, err = pcall(function()
        love.filesystem.write(SAVE_FILENAME, chunk)
        if love.filesystem.flush then
            pcall(love.filesystem.flush)
        end
    end)
    if not ok then
        print("Save failed:", err)
    else
        saveDirty = false
        saveTimer = 0
        print("GAME SAVED")
    end
end

local function loadGame()
    if love.filesystem.getInfo(SAVE_FILENAME) then
        local chunk, loadErr = love.filesystem.load(SAVE_FILENAME)
        if chunk then
            local ok, data = pcall(chunk)
            if ok and type(data) == "table" then
                coinsSaved = data.coinsSaved or coinsSaved or 0
                shipOwned = shipOwned or {}
                if type(data.shipOwned) == "table" then
                    for i = 1, (shipCount or 0) do
                        shipOwned[i] = data.shipOwned[i] or shipOwned[i] or false
                    end
                end
                equippedShip = data.equippedShip or equippedShip or 1
                shotPurchases = data.shotPurchases or shotPurchases or 0
                hpPurchases = data.hpPurchases or hpPurchases or 0
                print("GAME LOADED")
            else
                print("Save file corrupted or invalid format.")
            end
        else
            print("Failed to load save file:", loadErr)
        end
    else
        coinsSaved = coinsSaved or 580
        shipOwned = shipOwned or {}
        shotPurchases = shotPurchases or 0
        hpPurchases = hpPurchases or 0
        print("NO SAVE FOUND, USING DEFAULTS")
    end
end

-- -------------------------
-- Pricing helpers and constants
-- -------------------------
local BASE_HP = 100
local MAX_HP = 1000
local MAX_SHOT_PURCHASES = 20

local function getShotPrice(purchases)
    purchases = purchases or 0
    if purchases >= MAX_SHOT_PURCHASES then return nil end
    local nextIndex = purchases + 1
    return 500 * nextIndex
end

local function getHpPrice(hpPurchasesCount)
    hpPurchasesCount = hpPurchasesCount or 0
    local currentHP = BASE_HP + (hpPurchasesCount * 10)
    if currentHP >= MAX_HP then return nil end
    local price = 20 * (2 ^ hpPurchasesCount)
    return price
end

-- -------------------------
-- Globals
-- -------------------------
local ships, shipImages, shipPrices, shipOwned, shipCount
local enemyTypes, enemyImages, bossTypes, bossImages
local scene, paused, gameState
local menu, pauseMenu, pauseButton
local titleFont, uiFont, smallFont, bigFont
local player, bullets, bulletTimer, bulletDelay
local enemies, enemyTimer, enemyBullets, boss, nextBossTypeIndex
local coinsSaved, coinsCollected, currentLevel, coinsTargetForBoss
local difficulty
local shotPurchases, hpPurchases

-- Shop scroll state
local shopScrollY = 0
local shopScrollMin = 0
local shopScrollMax = 0
local shopDragging = false
local shopDragStartY = 0
local shopDragStartScroll = 0

-- Buy feedback
local buyMessageShot = nil
local buyMessageShotTimer = 0
local buyMessageHp = nil
local buyMessageHpTimer = 0
local BUY_MESSAGE_DURATION = 1.4

-- Audio
local clickSound = nil
local lossSound = nil

-- -------------------------
-- Initialization
-- -------------------------
function love.load()
    -- on Android, set identity so save files are stored in app-specific folder
    if love.filesystem and love.filesystem.setIdentity then
        pcall(function() love.filesystem.setIdentity(SAVE_IDENTITY, true) end)
    end

    -- On desktop set a fixed window; on Android skip window mode to let system handle it
    if love.system.getOS() ~= "Android" then
        love.window.setTitle("SpaceGalaxy - Command Center")
        love.window.setMode(800, 600, {resizable = false})
    else
        love.window.setTitle("SpaceGalaxy - Command Center")
    end

    scene = "menu"
    paused = false
    gameState = "playing"

    titleFont = love.graphics.newFont(40)
    uiFont = love.graphics.newFont(16)
    smallFont = love.graphics.newFont(12)
    bigFont = love.graphics.newFont(22)

    menu = {}
    menu.title = "SPACE GALAXY"
    menu.buttons = {
        {id = "start", label = "START MISSION", x = 250, y = 220, w = 300, h = 50, color = {0.1,0.8,0.1}},
        {id = "garage", label = "COMMAND CENTER", x = 250, y = 290, w = 300, h = 50, color = {1,0.8,0.1}},
        {id = "terminate", label = "TERMINATE", x = 250, y = 360, w = 300, h = 50, color = {0.9,0.1,0.1}}
    }

    pauseMenu = {}
    pauseMenu.title = "PAUSED"
    pauseMenu.buttons = {
        {id = "resume", label = "RESUME", x = 250, y = 220, w = 300, h = 50, color = {0.1,0.8,0.1}},
        {id = "restart", label = "RESTART", x = 250, y = 290, w = 300, h = 50, color = {1,0.8,0.1}},
        {id = "menu", label = "MENU", x = 250, y = 360, w = 300, h = 50, color = {0.9,0.1,0.1}}
    }

    pauseButton = {x = 740, y = 10, w = 48, h = 36, color = {0.2,0.6,1}, accent = {1,0.6,0.1}}

    difficulty = {
        baseEnemyBulletSpeed = 300,
        multiplier = 0,
        timer = 0,
        increaseInterval = 7,
        increment = 0.12
    }

    ships = {}
    shipImages = {}
    shipPrices = {}
    shipOwned = {}
    shipCount = 9
    local presetPrices = { 0, 500, 1500, 3000, 5000, 8000, 12000, 18000, 25000 }
    for i = 1, shipCount do
        ships[i] = "ship_" .. i
        shipPrices[i] = presetPrices[i] or (100 * i)
        shipOwned[i] = (i == 1)
        local filename = "ship_" .. i .. ".png"
        if love.filesystem.getInfo(filename) then
            local ok, img = pcall(love.graphics.newImage, filename)
            if ok and img then
                shipImages[i] = img
                shipImages[i]:setFilter("linear", "linear")
            else
                shipImages[i] = nil
            end
        else
            shipImages[i] = nil
        end
    end
    equippedShip = 1

    backgroundImage = nil
    if love.filesystem.getInfo("background.png") then
        local ok, bg = pcall(love.graphics.newImage, "background.png")
        if ok and bg then
            backgroundImage = bg
            backgroundImage:setFilter("linear", "linear")
        end
    end

    stars = {}
    for i = 1, 120 do
        stars[i] = { x = love.math.random(0,800), y = love.math.random(0,600), s = love.math.random(1,3), a = love.math.random() * 0.8 + 0.2 }
    end

    enemyTypes = {}
    enemyImages = {}
    for i = 1, 5 do
        local id = "enemy_" .. i
        enemyTypes[i] = {
            id = id,
            hp = 40 + (i-1)*20,
            speed = 110 + (i-1)*30,
            shootDelayMin = 0.6 - (i-1)*0.05,
            shootDelayMax = 1.2 - (i-1)*0.05,
            bulletSpeed = 240 + (i-1)*40
        }
        local filename = id .. ".png"
        if love.filesystem.getInfo(filename) then
            local ok, img = pcall(love.graphics.newImage, filename)
            if ok and img then
                enemyImages[i] = img
                enemyImages[i]:setFilter("linear", "linear")
            else
                enemyImages[i] = nil
            end
        else
            enemyImages[i] = nil
        end
    end

    bossTypes = {}
    bossImages = {}
    for i = 1, 3 do
        local id = "enemyboss_" .. i
        bossTypes[i] = {
            id = id,
            hp = 700 + (i-1)*400,
            speed = 90 + (i-1)*40,
            shootDelay = 0.8 - (i-1)*0.12,
            bulletSpeed = 320 + (i-1)*90,
            pattern = i
        }
        local filename = id .. ".png"
        if love.filesystem.getInfo(filename) then
            local ok, img = pcall(love.graphics.newImage, filename)
            if ok and img then
                bossImages[i] = img
                bossImages[i]:setFilter("linear", "linear")
            else
                bossImages[i] = nil
            end
        else
            bossImages[i] = nil
        end
    end

    local function tryLoadSound(basename)
        local exts = {".wav", ".ogg", ".mp3"}
        for _, ext in ipairs(exts) do
            local fname = basename .. ext
            if love.filesystem.getInfo(fname) then
                local ok, src = pcall(love.audio.newSource, fname, "static")
                if ok and src then
                    return src
                end
            end
        end
        return nil
    end

    clickSound = tryLoadSound("mixkit-game-click-1114")
    lossSound = tryLoadSound("mixkit-positive-interface-beep-221")

    if clickSound then clickSound:setVolume(0.7) end
    if lossSound then lossSound:setVolume(0.9) end

    -- تحميل الحفظ قبل بدء اللعبة
    loadGame()
    initGame()
end

-- -------------------------
-- Game init / reset
-- -------------------------
function initGame()
    gameState = "playing"

    shotPurchases = shotPurchases or 0
    hpPurchases = hpPurchases or 0

    player = {
        x = 375,
        y = 520,
        width = 45,
        height = 25,
        speed = 1000,
        hp = math.min(MAX_HP, BASE_HP + (hpPurchases or 0) * 10),
        targetX = 375
    }

    bullets = {}
    bulletTimer = 0
    bulletDelay = 0.12

    enemies = {}
    enemyTimer = 0

    boss = nil
    nextBossTypeIndex = 1

    enemyBullets = {}

    coinsSaved = coinsSaved or 580
    coinsCollected = 0
    currentLevel = 1
    coinsTargetForBoss = 400

    difficulty.multiplier = 0
    difficulty.timer = 0

    shopScrollY = 0
    shopDragging = false
    computeShopScrollBounds()

    buyMessageShot = nil
    buyMessageShotTimer = 0
    buyMessageHp = nil
    buyMessageHpTimer = 0

    saveTimer = 0
    saveDirty = false
end

local function resetRunToFirstLevel()
    enemies = {}
    bullets = {}
    enemyBullets = {}
    boss = nil

    player.x = 375
    player.targetX = 375
    player.y = 520
    player.hp = math.min(MAX_HP, BASE_HP + (hpPurchases or 0) * 10)

    currentLevel = 1
    coinsCollected = 0
    coinsTargetForBoss = 400
    difficulty.multiplier = 0
    difficulty.timer = 0
end

-- -------------------------
-- Shop scroll bounds
-- -------------------------
function computeShopScrollBounds()
    local upPanelH = 140
    local listStartY = 80 + upPanelH + 20
    local thumbH = 64
    local spacingY = 84
    local contentHeight = (shipCount * spacingY) - (spacingY - thumbH)
    local totalHeight = listStartY + contentHeight + 120
    local viewHeight = 600
    if totalHeight <= viewHeight then
        shopScrollMin = 0
        shopScrollMax = 0
    else
        shopScrollMax = 0
        shopScrollMin = viewHeight - totalHeight - 20
    end
    if shopScrollY < shopScrollMin then shopScrollY = shopScrollMin end
    if shopScrollY > shopScrollMax then shopScrollY = shopScrollMax end
end

-- -------------------------
-- Helpers
-- -------------------------
local function checkCollision(x1,y1,w1,h1,x2,y2,w2,h2)
    return x1 < x2 + w2 and x2 < x1 + w1 and y1 < y2 + h2 and y2 < y1 + h1
end

local function isInsideRect(mx, my, x, y, w, h)
    return mx >= x and mx <= x + w and my >= y and my <= y + h
end

local function drawButton(b)
    love.graphics.setColor(b.color)
    love.graphics.rectangle("fill", b.x, b.y, b.w, b.h, 8, 8)
    love.graphics.setColor(0,0,0)
    love.graphics.printf(b.label, b.x, b.y + (b.h/2 - 8), b.w, "center")
end

local function playClick()
    if clickSound then
        if clickSound:isPlaying() then clickSound:stop() end
        clickSound:play()
    end
end

local function playLoss()
    if lossSound then
        if lossSound:isPlaying() then lossSound:stop() end
        lossSound:play()
    end
end

-- -------------------------
-- Input handling
-- -------------------------
local function showBuyMessageShot()
    buyMessageShot = "SHOT +1"
    buyMessageShotTimer = BUY_MESSAGE_DURATION
end

local function showBuyMessageHp()
    buyMessageHp = "HP +10"
    buyMessageHpTimer = BUY_MESSAGE_DURATION
end

local function handlePointerPress(x, y)
    if scene == "menu" then
        for i = 1, #menu.buttons do
            local b = menu.buttons[i]
            if isInsideRect(x, y, b.x, b.y, b.w, b.h) then
                playClick()
                if b.id == "start" then
                    resetRunToFirstLevel()
                    scene = "playing"
                    paused = false
                elseif b.id == "garage" then
                    scene = "garage"
                elseif b.id == "terminate" then
                    saveGame()
                    love.event.quit()
                end
                return
            end
        end

    elseif scene == "garage" then
        local sx = x
        local sy = y - shopScrollY

        local centerX = 400
        local upPanelW, upPanelH = 360, 140
        local upX = centerX - upPanelW/2
        local upY = 80

        local colLeftX = upX + 16
        local colRightX = upX + upPanelW - 16 - 140
        local btnY = upY + 44
        local btnW, btnH = 140, 40

        -- SHOT button
        local shotBtn = { x = colLeftX, y = btnY, w = btnW, h = btnH }
        if isInsideRect(sx, sy, shotBtn.x, shotBtn.y, shotBtn.w, shotBtn.h) then
            local price = getShotPrice(shotPurchases)
            if price and (coinsSaved or 0) >= price then
                coinsSaved = coinsSaved - price
                shotPurchases = (shotPurchases or 0) + 1
                saveGame()
                showBuyMessageShot()
            end
            playClick()
            return
        end

        -- HP button
        local hpBtn = { x = colRightX, y = btnY, w = btnW, h = btnH }
        if isInsideRect(sx, sy, hpBtn.x, hpBtn.y, hpBtn.w, hpBtn.h) then
            local price = getHpPrice(hpPurchases)
            if price and (coinsSaved or 0) >= price then
                local currentHP = BASE_HP + (hpPurchases or 0) * 10
                if currentHP < MAX_HP then
                    coinsSaved = coinsSaved - price
                    hpPurchases = (hpPurchases or 0) + 1
                    player.hp = math.min(MAX_HP, BASE_HP + hpPurchases * 10)
                    saveGame()
                    showBuyMessageHp()
                end
            end
            playClick()
            return
        end

        -- Ships vertical list
        local listX = centerX - 180
        local listY = upY + upPanelH + 20
        local thumbW = 360
        local thumbH = 64
        local spacingY = 84

        for i = 1, shipCount do
            local syItem = listY + (i-1) * spacingY
            if isInsideRect(sx, sy, listX, syItem, thumbW, thumbH) then
                playClick()
                if shipOwned[i] then
                    equippedShip = i
                    saveGame()
                else
                    local price = shipPrices[i] or 0
                    if (coinsSaved or 0) >= price then
                        coinsSaved = coinsSaved - price
                        shipOwned[i] = true
                        equippedShip = i
                        saveGame()
                    end
                end
                return
            end
        end

        -- BACK button
        local backY = listY + (shipCount * spacingY) + 10
        local back = { x = 300, y = backY, w = 200, h = 44 }
        if isInsideRect(sx, sy, back.x, back.y, back.w, back.h) then
            playClick()
            scene = "menu"
            return
        end

        shopDragging = true
        shopDragStartY = y
        shopDragStartScroll = shopScrollY

    elseif scene == "playing" then
        if isInsideRect(x, y, pauseButton.x, pauseButton.y, pauseButton.w, pauseButton.h) then
            playClick()
            paused = true
            return
        end

        if paused then
            for i = 1, #pauseMenu.buttons do
                local b = pauseMenu.buttons[i]
                if isInsideRect(x, y, b.x, b.y, b.w, b.h) then
                    playClick()
                    if b.id == "resume" then
                        paused = false
                    elseif b.id == "restart" then
                        resetRunToFirstLevel()
                        paused = false
                        scene = "playing"
                    elseif b.id == "menu" then
                        scene = "menu"
                        paused = false
                    end
                    return
                end
            end
        else
            if gameState == "gameover" then
                playClick()
                resetRunToFirstLevel()
                gameState = "playing"
                paused = false
                return
            end
        end
    end
end

function love.mousepressed(x, y, button)
    if button ~= 1 then return end
    handlePointerPress(x, y)
end

function love.mousereleased(x, y, button)
    if button == 1 then
        shopDragging = false
    end
end

function love.mousemoved(x, y, dx, dy, istouch)
    if shopDragging and scene == "garage" then
        shopScrollY = shopDragStartScroll + (y - shopDragStartY)
        if shopScrollY > shopScrollMax then shopScrollY = shopScrollMax end
        if shopScrollY < shopScrollMin then shopScrollY = shopScrollMin end
    end
    if love.mouse.isDown(1) and scene == "playing" and not paused then
        player.targetX = x - (player.width / 2)
    end
end

function love.wheelmoved(x, y)
    if scene == "garage" then
        local delta = y * 40
        shopScrollY = shopScrollY + delta
        if shopScrollY > shopScrollMax then shopScrollY = shopScrollMax end
        if shopScrollY < shopScrollMin then shopScrollY = shopScrollMin end
    end
end

function love.touchpressed(id, x, y, dx, dy, pressure)
    local px, py
    if x <= 1 and y <= 1 then
        px = x * love.graphics.getWidth()
        py = y * love.graphics.getHeight()
    else
        px, py = x, y
    end
    handlePointerPress(px, py)
end

function love.touchmoved(id, x, y, dx, dy, pressure)
    local px, py
    if x <= 1 and y <= 1 then
        px = x * love.graphics.getWidth()
        py = y * love.graphics.getHeight()
    else
        px, py = x, y
    end
    if shopDragging and scene == "garage" then
        shopScrollY = shopDragStartScroll + (py - shopDragStartY)
        if shopScrollY > shopScrollMax then shopScrollY = shopScrollMax end
        if shopScrollY < shopScrollMin then shopScrollY = shopScrollMin end
    else
        if scene == "playing" and not paused then
            player.targetX = px - (player.width / 2)
        end
    end
end

function love.touchreleased(id, x, y, dx, dy, pressure)
    shopDragging = false
end

-- -------------------------
-- Spawning enemies / boss
-- -------------------------
local function spawnEnemy()
    local idx = love.math.random(1, #enemyTypes)
    local t = enemyTypes[idx]
    local ex = love.math.random(0, 800 - 40)
    local e = {
        typeIndex = idx,
        id = t.id,
        x = ex,
        y = -40,
        width = 40,
        height = 40,
        speed = t.speed * (1 + difficulty.multiplier * 0.25),
        hp = t.hp,
        shootTimer = 0,
        shootDelay = love.math.random() * (t.shootDelayMax - t.shootDelayMin) + t.shootDelayMin,
        bulletSpeed = t.bulletSpeed * (1 + difficulty.multiplier * 0.18)
    }
    table.insert(enemies, e)
end

local function spawnBoss()
    local bt = bossTypes[nextBossTypeIndex]
    if not bt then nextBossTypeIndex = 1; bt = bossTypes[1] end
    boss = {
        typeIndex = nextBossTypeIndex,
        id = bt.id,
        x = 320,
        y = -120,
        targetY = 70,
        width = 160,
        height = 75,
        speed = bt.speed * (1 + difficulty.multiplier * 0.08),
        hp = bt.hp * (1 + difficulty.multiplier * 0.25),
        maxHp = bt.hp * (1 + difficulty.multiplier * 0.25),
        shootTimer = 0,
        shootDelay = math.max(0.25, bt.shootDelay * (1 - difficulty.multiplier * 0.08)),
        bulletSpeed = bt.bulletSpeed * (1 + difficulty.multiplier * 0.25),
        pattern = bt.pattern
    }
    nextBossTypeIndex = nextBossTypeIndex + 1
    if nextBossTypeIndex > #bossTypes then nextBossTypeIndex = 1 end
    enemies = {}
end

-- -------------------------
-- Update loop
-- -------------------------
function love.update(dt)
    if buyMessageShotTimer and buyMessageShotTimer > 0 then
        buyMessageShotTimer = buyMessageShotTimer - dt
        if buyMessageShotTimer <= 0 then
            buyMessageShot = nil
            buyMessageShotTimer = 0
        end
    end
    if buyMessageHpTimer and buyMessageHpTimer > 0 then
        buyMessageHpTimer = buyMessageHpTimer - dt
        if buyMessageHpTimer <= 0 then
            buyMessageHp = nil
            buyMessageHpTimer = 0
        end
    end

    if saveDirty then
        saveTimer = saveTimer + dt
        if saveTimer >= saveInterval then
            saveGame()
        end
    end

    if scene ~= "playing" then return end
    if paused or gameState == "gameover" then return end

    difficulty.timer = difficulty.timer + dt
    if difficulty.timer >= difficulty.increaseInterval then
        difficulty.timer = difficulty.timer - difficulty.increaseInterval
        difficulty.multiplier = difficulty.multiplier + difficulty.increment
        if difficulty.multiplier > 5 then difficulty.multiplier = 5 end
    end

    local enemyDelay = math.max(0.08, 0.8 - (currentLevel * 0.09) - (difficulty.multiplier * 0.07))
    local enemyBulletSpeedBase = difficulty.baseEnemyBulletSpeed * (1 + difficulty.multiplier * 0.2)

    if love.keyboard.isDown("left") or love.keyboard.isDown("a") then
        player.x = player.x - player.speed * dt
    end
    if love.keyboard.isDown("right") or love.keyboard.isDown("d") then
        player.x = player.x + player.speed * dt
    end

    if player.targetX then
        if math.abs(player.x - player.targetX) > 1 then
            if player.x < player.targetX then
                player.x = player.x + player.speed * dt
                if player.x > player.targetX then player.x = player.targetX end
            else
                player.x = player.x - player.speed * dt
                if player.x < player.targetX then player.x = player.targetX end
            end
        end
    end

    if player.x < 0 then player.x = 0 end
    if player.x > 800 - player.width then player.x = 800 - player.width end

    bulletTimer = bulletTimer + dt
    if bulletTimer >= bulletDelay then
        local shots = 1 + (shotPurchases or 0)
        shots = math.max(1, math.min(shots, MAX_SHOT_PURCHASES + 1))
        local centerX = player.x + player.width/2
        local spacing = 8
        local totalWidth = (shots - 1) * spacing
        for s = 1, shots do
            local offset = (s - 1) * spacing - totalWidth / 2
            table.insert(bullets, { x = centerX + offset - 2, y = player.y, width = 4, height = 15, speed = 940, vx = 0 })
        end
        bulletTimer = 0
    end
    for i = #bullets, 1, -1 do
        local b = bullets[i]
        b.y = b.y - b.speed * dt
        b.x = b.x + (b.vx or 0) * dt
        if b.y < -b.height or b.x < -100 or b.x > 900 then table.remove(bullets, i) end
    end

    if boss == nil and (coinsCollected or 0) >= coinsTargetForBoss then
        spawnBoss()
    end

    if boss == nil then
        enemyTimer = enemyTimer + dt
        if enemyTimer >= enemyDelay then
            spawnEnemy()
            enemyTimer = 0
        end

        for eIndex = #enemies, 1, -1 do
            local e = enemies[eIndex]
            e.y = e.y + e.speed * dt

            e.shootTimer = e.shootTimer + dt
            if e.shootTimer >= e.shootDelay then
                local ex = e.x + e.width/2
                local ey = e.y + e.height
                table.insert(enemyBullets, { x = ex - 2, y = ey, width = 5, height = 8, vx = 0, vy = (e.bulletSpeed or enemyBulletSpeedBase) })
                e.shootTimer = 0
            end

            if checkCollision(e.x, e.y, e.width, e.height, player.x, player.y, player.width, player.height) then
                player.hp = player.hp - 20
                table.remove(enemies, eIndex)
                if player.hp <= 0 then
                    gameState = "gameover"
                    saveGame()
                    playLoss()
                end
            elseif e.y > 600 then
                table.remove(enemies, eIndex)
            else
                for bIndex = #bullets, 1, -1 do
                    local b = bullets[bIndex]
                    if checkCollision(b.x, b.y, b.width, b.height, e.x, e.y, e.width, e.height) then
                        e.hp = e.hp - 20
                        table.remove(bullets, bIndex)
                        if e.hp <= 0 then
                            table.remove(enemies, eIndex)
                            coinsSaved = (coinsSaved or 0) + 12
                            coinsCollected = (coinsCollected or 0) + 12
                            saveDirty = true
                        end
                        break
                    end
                end
            end
        end
    else
        if boss.y < boss.targetY then
            boss.y = boss.y + 150 * dt
        else
            local bossCenterX = boss.x + boss.width/2
            local playerCenterX = player.x + player.width/2
            if bossCenterX < playerCenterX then
                boss.x = boss.x + boss.speed * dt
            elseif bossCenterX > playerCenterX then
                boss.x = boss.x - boss.speed * dt
            end
        end

        boss.shootTimer = boss.shootTimer + dt
        if boss.shootTimer >= boss.shootDelay then
            if boss.pattern == 1 then
                local spawnPoints = { boss.x + 20, boss.x + boss.width/2, boss.x + boss.width - 20 }
                for _, sx in ipairs(spawnPoints) do
                    local angle = math.atan2((player.y + player.height/2) - (boss.y + boss.height), (player.x + player.width/2) - sx)
                    local dx = math.cos(angle) * boss.bulletSpeed
                    local dy = math.sin(angle) * boss.bulletSpeed
                    table.insert(enemyBullets, { x = sx, y = boss.y + boss.height, width = 10, height = 14, vx = dx, vy = dy })
                end
                for i = -1, 1, 2 do
                    table.insert(enemyBullets, { x = boss.x + (boss.width/2) + i*40, y = boss.y + boss.height, width = 8, height = 10, vx = i*120, vy = boss.bulletSpeed*0.6 })
                end
            elseif boss.pattern == 2 then
                local centerX = boss.x + boss.width/2
                for a = -1.2, 1.2, 0.3 do
                    local angle = math.pi/2 + a
                    local dx = math.cos(angle) * boss.bulletSpeed
                    local dy = math.sin(angle) * boss.bulletSpeed
                    table.insert(enemyBullets, { x = centerX, y = boss.y + boss.height, width = 9, height = 11, vx = dx, vy = dy })
                end
            else
                local angle = math.atan2((player.y + player.height/2) - (boss.y + boss.height), (player.x + player.width/2) - (boss.x + boss.width/2))
                for i = 1, 5 do
                    local speedFactor = boss.bulletSpeed + i*60
                    local dx = math.cos(angle) * speedFactor
                    local dy = math.sin(angle) * speedFactor
                    table.insert(enemyBullets, { x = boss.x + boss.width/2, y = boss.y + boss.height, width = 7, height = 10, vx = dx, vy = dy })
                end
            end
            boss.shootTimer = 0
        end

        for bIndex = #bullets, 1, -1 do
            local b = bullets[bIndex]
            if checkCollision(b.x, b.y, b.width, b.height, boss.x, boss.y, boss.width, boss.height) then
                table.remove(bullets, bIndex)
                boss.hp = boss.hp - 15
                if boss.hp <= 0 then
                    boss = nil
                    currentLevel = currentLevel + 1
                    coinsSaved = (coinsSaved or 0) + 200
                    coinsCollected = 0
                    saveDirty = true
                    coinsTargetForBoss = 400
                    player.hp = math.min(MAX_HP, player.hp + 30)
                    enemies = {}
                    bullets = {}
                    enemyBullets = {}
                    break
                end
            end
        end
    end

    for i = #enemyBullets, 1, -1 do
        local eb = enemyBullets[i]
        eb.x = eb.x + (eb.vx or 0) * dt
        eb.y = eb.y + (eb.vy or 0) * dt

        if checkCollision(eb.x, eb.y, eb.width, eb.height, player.x, player.y, player.width, player.height) then
            player.hp = player.hp - 12
            table.remove(enemyBullets, i)
            if player.hp <= 0 then
                gameState = "gameover"
                saveGame()
                playLoss()
            end
        elseif eb.y > 900 or eb.x < -200 or eb.x > 1000 then
            table.remove(enemyBullets, i)
        end
    end
end

-- -------------------------
-- Drawing
-- -------------------------
function love.draw()
    if scene == "playing" and backgroundImage then
        love.graphics.setColor(1,1,1)
        local bw = backgroundImage:getWidth()
        local bh = backgroundImage:getHeight()
        local sx = 800 / bw
        local sy = 600 / bh
        love.graphics.draw(backgroundImage, 0, 0, 0, sx, sy)
    else
        love.graphics.clear(0.03, 0.03, 0.07)
        for _, s in ipairs(stars) do
            love.graphics.setColor(1,1,1, s.a)
            love.graphics.points(s.x, s.y)
        end
    end

    if scene == "menu" then
        love.graphics.setColor(0.2,1,1)
        love.graphics.setFont(titleFont)
        love.graphics.printf(menu.title, 0, 80, 800, "center")
        love.graphics.setFont(uiFont)
        for i = 1, #menu.buttons do drawButton(menu.buttons[i]) end

    elseif scene == "garage" then
        love.graphics.setColor(0.9,0.9,1)
        love.graphics.setFont(titleFont)
        love.graphics.printf("COMMAND CENTER", 0, 20, 800, "center")

        love.graphics.setFont(bigFont)
        love.graphics.setColor(1,0.85,0.15)
        love.graphics.printf("COINS: " .. (coinsSaved or 0), 0, 60, 800, "center")

        love.graphics.push()
        love.graphics.translate(0, shopScrollY)

        local centerX = 400
        local upPanelW, upPanelH = 360, 140
        local upX = centerX - upPanelW/2
        local upY = 80

        love.graphics.setColor(0.08,0.08,0.12,0.95)
        love.graphics.rectangle("fill", upX, upY, upPanelW, upPanelH, 10, 10)
        love.graphics.setColor(1,1,1)
        love.graphics.setFont(uiFont)
        love.graphics.printf("UPGRADES", upX, upY + 8, upPanelW, "center")

        local colLeftX = upX + 16
        local colRightX = upX + upPanelW - 16 - 140
        local btnY = upY + 44
        local btnW, btnH = 140, 40

        local shotPrice = getShotPrice(shotPurchases)
        love.graphics.setFont(smallFont)
        love.graphics.setColor(1,1,1)
        love.graphics.printf("SHOT", colLeftX, upY + 18, btnW, "left")
        if shotPrice then
            love.graphics.setColor(0.2,0.6,0.2)
            love.graphics.rectangle("fill", colLeftX, btnY, btnW, btnH, 6, 6)
            love.graphics.setColor(0,0,0)
            love.graphics.printf("BUY", colLeftX, btnY + 10, btnW, "center")
            love.graphics.setColor(1,1,1)
            love.graphics.printf(shotPrice .. "c", colLeftX, btnY + btnH + 6, btnW, "center")
        else
            love.graphics.setColor(0.4,0.4,0.4)
            love.graphics.rectangle("fill", colLeftX, btnY, btnW, btnH, 6, 6)
            love.graphics.setColor(0,0,0)
            love.graphics.printf("MAX", colLeftX, btnY + 10, btnW, "center")
            love.graphics.setColor(1,1,1)
            love.graphics.printf("MAX", colLeftX, btnY + btnH + 6, btnW, "center")
        end
        love.graphics.setColor(1,1,1)
        love.graphics.printf("Lv: " .. (shotPurchases or 0) .. " / " .. MAX_SHOT_PURCHASES, colLeftX, btnY + btnH + 26, btnW, "center")

        local hpPrice = getHpPrice(hpPurchases)
        love.graphics.setFont(smallFont)
        love.graphics.setColor(1,1,1)
        love.graphics.printf("HP +10", colRightX, upY + 18, btnW, "left")
        if hpPrice then
            love.graphics.setColor(0.2,0.6,0.2)
            love.graphics.rectangle("fill", colRightX, btnY, btnW, btnH, 6, 6)
            love.graphics.setColor(0,0,0)
            love.graphics.printf("BUY", colRightX, btnY + 10, btnW, "center")
            love.graphics.setColor(1,1,1)
            love.graphics.printf(hpPrice .. "c", colRightX, btnY + btnH + 6, btnW, "center")
        else
            love.graphics.setColor(0.4,0.4,0.4)
            love.graphics.rectangle("fill", colRightX, btnY, btnW, btnH, 6, 6)
            love.graphics.setColor(0,0,0)
            love.graphics.printf("MAX", colRightX, btnY + 10, btnW, "center")
            love.graphics.setColor(1,1,1)
            love.graphics.printf("MAX", colRightX, btnY + btnH + 6, btnW, "center")
        end
        love.graphics.setColor(1,1,1)
        love.graphics.printf("Lv: " .. (hpPurchases or 0) .. "    HP: " .. math.min(MAX_HP, BASE_HP + (hpPurchases or 0) * 10), colRightX - 40, btnY + btnH + 26, btnW + 80, "center")

        if buyMessageShot then
            love.graphics.setFont(smallFont)
            love.graphics.setColor(1,1,1)
            love.graphics.printf(buyMessageShot, colLeftX, btnY - 18, btnW, "center")
        end
        if buyMessageHp then
            love.graphics.setFont(smallFont)
            love.graphics.setColor(1,1,1)
            love.graphics.printf(buyMessageHp, colRightX, btnY - 18, btnW, "center")
        end

        local listX = centerX - 180
        local listY = upY + upPanelH + 20
        local thumbW = 360
        local thumbH = 64
        local spacingY = 84

        love.graphics.setFont(uiFont)
        for i = 1, shipCount do
            local sy = listY + (i-1) * spacingY

            love.graphics.setColor(0.12, 0.12, 0.16)
            love.graphics.rectangle("fill", listX, sy, thumbW, thumbH, 8, 8)

            if shipImages[i] then
                love.graphics.setColor(1,1,1)
                local img = shipImages[i]
                local iw, ih = img:getWidth(), img:getHeight()
                local scale = math.min((thumbW - 12) / iw, (thumbH - 28) / ih)
                love.graphics.draw(img, listX + thumbW/2, sy + (thumbH/2) - 6, 0, scale, scale, iw/2, ih/2)
            else
                love.graphics.setColor(0.6,0.6,0.6)
                love.graphics.rectangle("fill", listX + 12, sy + 8, thumbW - 24, thumbH - 36, 6, 6)
                love.graphics.setColor(0,0,0)
                love.graphics.printf(ships[i], listX, sy + thumbH/2 - 6, thumbW, "center")
            end

            if shipOwned[i] then
                if equippedShip == i then
                    love.graphics.setColor(0.2, 0.8, 0.2)
                    love.graphics.printf("ACTIVE", listX, sy + thumbH - 18, thumbW, "center")
                else
                    love.graphics.setColor(0.6, 0.9, 0.6)
                    love.graphics.printf("OWNED", listX, sy + thumbH - 18, thumbW, "center")
                end
            else
                love.graphics.setColor(1, 0.85, 0.2)
                love.graphics.printf(shipPrices[i] .. "c", listX, sy + thumbH - 18, thumbW, "center")
            end

            if equippedShip == i then
                love.graphics.setColor(0.2, 0.6, 1, 0.6)
                love.graphics.rectangle("line", listX-2, sy-2, thumbW+4, thumbH+4, 10, 10)
            end
        end

        local backY = listY + (shipCount * spacingY) + 10
        local back = { x = 300, y = backY, w = 200, h = 44 }
        love.graphics.setColor(0.9,0.1,0.1)
        love.graphics.rectangle("fill", back.x, back.y, back.w, back.h, 8, 8)
        love.graphics.setColor(0,0,0)
        love.graphics.setFont(bigFont)
        love.graphics.printf("BACK", back.x, back.y + 6, back.w, "center")

        love.graphics.pop()

        local barW, barH = 8, 160
        local barX = 780
        local barY = 80
        love.graphics.setColor(0.12,0.12,0.16,0.8)
        love.graphics.rectangle("fill", barX, barY, barW, barH, 4, 4)
        local totalHeight = math.max(600, math.abs(shopScrollMin) + 600)
        local thumbH = math.max(24, (600 / totalHeight) * barH)
        local t = 0
        if shopScrollMin ~= shopScrollMax then
            t = (shopScrollY - shopScrollMin) / (shopScrollMax - shopScrollMin)
        end
        local thumbY = barY + (1 - t) * (barH - thumbH)
        love.graphics.setColor(1,0.85,0.15)
        love.graphics.rectangle("fill", barX + 1, thumbY, barW - 2, thumbH, 4, 4)

    elseif scene == "playing" then
        if gameState == "playing" then
            if shipImages[equippedShip] then
                love.graphics.setColor(1,1,1)
                local img = shipImages[equippedShip]
                local iw, ih = img:getWidth(), img:getHeight()
                local baseScale = 1
                if iw > player.width or ih > player.height then
                    baseScale = math.min(player.width / iw, player.height / ih)
                end
                local finalScale = baseScale * 1.12
                if finalScale <= 0 then finalScale = 1 end
                local sx = player.x + player.width/2
                local sy = player.y + player.height/2
                love.graphics.draw(img, sx, sy, 0, finalScale, finalScale, iw/2, ih/2)
            else
                love.graphics.setColor(1,1,1)
                love.graphics.rectangle("fill", player.x, player.y, player.width, player.height)
            end

            love.graphics.setColor(1, 0.1, 0.1)
            for _, b in ipairs(bullets) do
                love.graphics.rectangle("fill", b.x, b.y, b.width, b.height)
            end

            if boss == nil then
                for _, e in ipairs(enemies) do
                    if enemyImages[e.typeIndex] then
                        love.graphics.setColor(1,1,1)
                        local img = enemyImages[e.typeIndex]
                        local iw, ih = img:getWidth(), img:getHeight()
                        local scale = math.min(e.width / iw, e.height / ih)
                        love.graphics.draw(img, e.x + e.width/2, e.y + e.height/2, 0, scale, scale, iw/2, ih/2)
                    else
                        love.graphics.setColor(0.1,0.9,0.1)
                        love.graphics.rectangle("fill", e.x, e.y, e.width, e.height)
                    end
                end
            else
                if bossImages[boss.typeIndex] then
                    love.graphics.setColor(1,1,1)
                    local img = bossImages[boss.typeIndex]
                    local iw, ih = img:getWidth(), img:getHeight()
                    local scale = math.min(boss.width / iw, boss.height / ih)
                    love.graphics.draw(img, boss.x + boss.width/2, boss.y + boss.height/2, 0, scale, scale, iw/2, ih/2)
                else
                    love.graphics.setColor(0.6,0.1,0.8)
                    love.graphics.rectangle("fill", boss.x, boss.y, boss.width, boss.height)
                end
                love.graphics.setColor(1,1,1)
                love.graphics.setFont(uiFont)
                love.graphics.printf("BOSS HP: " .. math.max(0, math.floor(boss.hp)), 0, 8, 800, "center")
            end

            love.graphics.setColor(1, 0.9, 0.1)
            for _, eb in ipairs(enemyBullets) do
                love.graphics.rectangle("fill", eb.x, eb.y, eb.width, eb.height)
            end

            love.graphics.setColor(pauseButton.color)
            love.graphics.rectangle("fill", pauseButton.x, pauseButton.y, pauseButton.w, pauseButton.h, 6, 6)
            love.graphics.setColor(pauseButton.accent)
            love.graphics.rectangle("fill", pauseButton.x, pauseButton.y + pauseButton.h - 6, pauseButton.w, 6, 6, 6, 6)
            love.graphics.setColor(0,0,0)
            love.graphics.setFont(smallFont)
            love.graphics.printf("PAUSE", pauseButton.x, pauseButton.y + 6, pauseButton.w, "center")

            love.graphics.setColor(1,1,1)
            love.graphics.setFont(smallFont)
            love.graphics.print("LEVEL: " .. currentLevel, 10, 10)
            love.graphics.setColor(1,0.85,0.15)
            love.graphics.print("SHOP COINS: " .. (coinsSaved or 0), 10, 30)
            love.graphics.setColor(1,0.8,0.1)
            love.graphics.print("COLLECTED: " .. (coinsCollected or 0) .. " / " .. coinsTargetForBoss, 10, 50)
            love.graphics.setColor(0.2,0.9,0.6)
            love.graphics.print("SHOT Lv: " .. (shotPurchases or 0) .. " / " .. MAX_SHOT_PURCHASES, 10, 70)
            love.graphics.setColor(0.1,0.9,0.1)
            love.graphics.print("HP: " .. player.hp, 10, 90)
            love.graphics.setColor(1,1,1)
            love.graphics.print(string.format("DIFFICULTY: %.2f", 1 + difficulty.multiplier), 10, 110)

        elseif gameState == "gameover" then
            love.graphics.setColor(1, 0.1, 0.1)
            love.graphics.setFont(titleFont)
            love.graphics.printf("GAME OVER", 0, 220, 800, "center")
            love.graphics.setColor(1,1,1)
            love.graphics.setFont(uiFont)
            love.graphics.printf("Tap to restart (keeps shop coins and purchases) or return to menu", 0, 280, 800, "center")
            love.graphics.setColor(1, 0.8, 0.1)
            love.graphics.printf("LEVEL WILL RESET TO 1    SHOP COINS SAVED: " .. (coinsSaved or 0), 0, 320, 800, "center")
        end

        if paused then
            love.graphics.setColor(0,0,0,0.6)
            love.graphics.rectangle("fill", 0, 0, 800, 600)
            love.graphics.setColor(1,1,1)
            love.graphics.setFont(titleFont)
            love.graphics.printf(pauseMenu.title, 0, 120, 800, "center")
            love.graphics.setFont(uiFont)
            for i = 1, #pauseMenu.buttons do
                local b = pauseMenu.buttons[i]
                love.graphics.setColor(b.color)
                love.graphics.rectangle("fill", b.x, b.y, b.w, b.h, 8, 8)
                love.graphics.setColor(0,0,0)
                love.graphics.printf(b.label, b.x, b.y + 14, b.w, "center")
            end
        end
    end
end

-- حفظ عند فقدان التركيز (تصغير النافذة أو الانتقال لتطبيق آخر)
function love.focus(f)
    if not f then
        saveGame()
    end
end

function love.quit()
    saveGame()
end
